import { createFileRoute } from '@tanstack/react-router'
import { Clock, DatabaseBackup, Headset, ShieldCheck } from 'lucide-react'
import { BRAND_NAME, Navbar } from '@/components/Navbar'
import { PricingComparison } from '@/components/PricingComparison'

export const Route = createFileRoute('/')({ component: HomePage })

const valueProps = [
  {
    icon: Clock,
    title: 'זמינות 99.9%',
    text: 'תשתית שרתים מנוטרת 24/7 עם התחייבות SLA.',
  },
  {
    icon: ShieldCheck,
    title: 'אבטחה מובנית',
    text: 'SSL והגנת DDOS כלולים – בלי תוספות ובלי הפתעות.',
  },
  {
    icon: DatabaseBackup,
    title: 'גיבוי יומי אוטומטי',
    text: 'שחזור מלא של האתר בלחיצה, מתי שצריך.',
  },
  {
    icon: Headset,
    title: 'תמיכה אנושית בעברית',
    text: 'צוות מומחים זמין לכל שאלה, ללא בוטים.',
  },
]

function HomePage() {
  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar />

      <main>
        <section
          id="pricing"
          className="relative overflow-hidden scroll-mt-24 pb-24 pt-16 sm:pt-20 lg:pb-32"
        >
          {/* Deep-blue backdrop behind the heading and the top half of the cards */}
          <div
            aria-hidden
            className="absolute inset-x-0 top-0 h-[30rem] bg-gradient-to-b from-[#071530] via-[#0a1f44] to-[#0e2d63] lg:h-[34rem]"
          />
          <div
            aria-hidden
            className="absolute -top-40 left-1/2 h-[30rem] w-[60rem] -translate-x-1/2 rounded-full bg-blue-500/20 blur-3xl"
          />

          <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-3xl text-center">
              <span className="inline-flex items-center rounded-full bg-white/10 px-4 py-1.5 text-sm font-semibold text-pink-300 ring-1 ring-white/15">
                WooCommerce Super
              </span>
              <h1 className="mt-6 text-4xl font-extrabold leading-tight text-white sm:text-5xl">
                אחסון מנוהל שבנוי למכור
              </h1>
              <p className="mt-5 text-lg leading-8 text-blue-100 sm:text-xl">
                חנות מהירה, מאובטחת וזמינה תמיד – עם אחסון NVMe מהיר, משאבים פרטיים ותמיכה
                מקצועית בעברית. בחרו את החבילה שמתאימה לקצב הצמיחה שלכם.
              </p>
            </div>

            <div className="mt-16 lg:mt-20">
              <PricingComparison />
            </div>

            <p className="mt-12 text-center text-sm text-slate-500">
              כל המחירים בשקלים חדשים ואינם כוללים מע״מ · העברת אתר חינם מכל ספק אחר
            </p>
          </div>
        </section>

        <section className="border-t border-slate-200 bg-white py-16 sm:py-20">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <h2 className="text-center text-2xl font-bold text-[#0a1f44] sm:text-3xl">
              למה עסקים בוחרים ב{BRAND_NAME}
            </h2>
            <div className="mt-12 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {valueProps.map((item) => (
                <div
                  key={item.title}
                  className="rounded-2xl bg-slate-50 p-6 ring-1 ring-slate-100 transition-shadow hover:shadow-md"
                >
                  <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-blue-600 text-white shadow-md shadow-blue-600/20">
                    <item.icon className="h-6 w-6" aria-hidden />
                  </span>
                  <h3 className="mt-5 text-lg font-bold text-slate-900">{item.title}</h3>
                  <p className="mt-2 leading-7 text-slate-600">{item.text}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-[#071530] py-10 text-center text-sm text-blue-200">
        © {new Date().getFullYear()} {BRAND_NAME} · אחסון מנוהל ושירותי IT
      </footer>
    </div>
  )
}
