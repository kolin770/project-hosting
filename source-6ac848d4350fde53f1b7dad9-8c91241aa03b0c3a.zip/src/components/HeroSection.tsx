import { useEffect, useRef } from 'react'
import { motion, useReducedMotion } from 'framer-motion'
import { Activity, ArrowLeft, Cpu, Gauge, Headset, ShieldCheck, Sparkles } from 'lucide-react'

type Node = { x: number; y: number; vx: number; vy: number; r: number; hub: boolean }
type Packet = { from: number; to: number; t: number; speed: number }

const LINK_DISTANCE = 150

/**
 * Full-viewport animated infrastructure network: drifting server nodes, faint
 * links between nearby nodes and data packets travelling along those links.
 * Rendered on a single canvas at low opacity so it never competes with content.
 * Pauses when the tab is hidden and draws one static frame for reduced-motion users.
 */
export function InfrastructureBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const reduceMotion = useReducedMotion()

  useEffect(() => {
    const canvas = canvasRef.current
    const ctx = canvas?.getContext('2d')
    if (!canvas || !ctx) return

    let width = 0
    let height = 0
    let nodes: Node[] = []
    let packets: Packet[] = []
    let frame = 0
    const pointer = { x: -9999, y: -9999 }

    const seed = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2)
      width = window.innerWidth
      height = window.innerHeight
      canvas.width = width * dpr
      canvas.height = height * dpr
      canvas.style.width = `${width}px`
      canvas.style.height = `${height}px`
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)

      const count = Math.min(90, Math.round((width * height) / 16000))
      nodes = Array.from({ length: count }, () => {
        const hub = Math.random() < 0.12
        return {
          x: Math.random() * width,
          y: Math.random() * height,
          vx: (Math.random() - 0.5) * 0.22,
          vy: (Math.random() - 0.5) * 0.22,
          r: hub ? 2.6 : 1.3,
          hub,
        }
      })
      packets = []
    }

    const spawnPacket = () => {
      const from = Math.floor(Math.random() * nodes.length)
      const a = nodes[from]
      let best = -1
      let bestD = LINK_DISTANCE
      for (let i = 0; i < nodes.length; i++) {
        if (i === from) continue
        const d = Math.hypot(nodes[i].x - a.x, nodes[i].y - a.y)
        if (d < bestD && Math.random() > 0.3) {
          bestD = d
          best = i
        }
      }
      if (best >= 0) packets.push({ from, to: best, t: 0, speed: 0.006 + Math.random() * 0.01 })
    }

    const draw = (animate: boolean) => {
      ctx.clearRect(0, 0, width, height)

      if (animate) {
        for (const n of nodes) {
          n.x += n.vx
          n.y += n.vy
          if (n.x < -20) n.x = width + 20
          if (n.x > width + 20) n.x = -20
          if (n.y < -20) n.y = height + 20
          if (n.y > height + 20) n.y = -20
        }
      }

      // Links
      ctx.lineWidth = 0.6
      for (let i = 0; i < nodes.length; i++) {
        const a = nodes[i]
        for (let j = i + 1; j < nodes.length; j++) {
          const b = nodes[j]
          const dx = a.x - b.x
          const dy = a.y - b.y
          const d2 = dx * dx + dy * dy
          if (d2 > LINK_DISTANCE * LINK_DISTANCE) continue
          const alpha = (1 - Math.sqrt(d2) / LINK_DISTANCE) * 0.22
          ctx.strokeStyle = `rgba(99, 179, 237, ${alpha})`
          ctx.beginPath()
          ctx.moveTo(a.x, a.y)
          ctx.lineTo(b.x, b.y)
          ctx.stroke()
        }
        // Gentle highlight of nodes near the pointer
        const pd = Math.hypot(a.x - pointer.x, a.y - pointer.y)
        if (pd < 180) {
          ctx.strokeStyle = `rgba(167, 139, 250, ${(1 - pd / 180) * 0.35})`
          ctx.beginPath()
          ctx.moveTo(a.x, a.y)
          ctx.lineTo(pointer.x, pointer.y)
          ctx.stroke()
        }
      }

      // Nodes (hubs drawn as small server squares)
      for (const n of nodes) {
        if (n.hub) {
          ctx.fillStyle = 'rgba(34, 211, 238, 0.12)'
          ctx.beginPath()
          ctx.arc(n.x, n.y, 9, 0, Math.PI * 2)
          ctx.fill()
          ctx.fillStyle = 'rgba(165, 243, 252, 0.8)'
          ctx.fillRect(n.x - 2.5, n.y - 2.5, 5, 5)
        } else {
          ctx.fillStyle = 'rgba(148, 163, 184, 0.55)'
          ctx.beginPath()
          ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2)
          ctx.fill()
        }
      }

      // Data packets
      if (animate) {
        if (packets.length < 14 && Math.random() < 0.08) spawnPacket()
        packets = packets.filter((p) => (p.t += p.speed) < 1)
      }
      for (const p of packets) {
        const a = nodes[p.from]
        const b = nodes[p.to]
        if (!a || !b) continue
        const x = a.x + (b.x - a.x) * p.t
        const y = a.y + (b.y - a.y) * p.t
        const glow = ctx.createRadialGradient(x, y, 0, x, y, 6)
        glow.addColorStop(0, 'rgba(103, 232, 249, 0.9)')
        glow.addColorStop(1, 'rgba(103, 232, 249, 0)')
        ctx.fillStyle = glow
        ctx.beginPath()
        ctx.arc(x, y, 6, 0, Math.PI * 2)
        ctx.fill()
      }
    }

    const loop = () => {
      draw(true)
      frame = requestAnimationFrame(loop)
    }

    const start = () => {
      cancelAnimationFrame(frame)
      if (reduceMotion) draw(false)
      else frame = requestAnimationFrame(loop)
    }

    const onResize = () => {
      seed()
      start()
    }
    const onVisibility = () => {
      if (document.hidden) cancelAnimationFrame(frame)
      else start()
    }
    const onPointer = (e: PointerEvent) => {
      pointer.x = e.clientX
      pointer.y = e.clientY
    }

    seed()
    start()
    window.addEventListener('resize', onResize)
    document.addEventListener('visibilitychange', onVisibility)
    window.addEventListener('pointermove', onPointer, { passive: true })
    return () => {
      cancelAnimationFrame(frame)
      window.removeEventListener('resize', onResize)
      document.removeEventListener('visibilitychange', onVisibility)
      window.removeEventListener('pointermove', onPointer)
    }
  }, [reduceMotion])

  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
      {/* Obsidian → slate base with cyber-blue / violet glows */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,#0f1b3d_0%,#070b19_55%,#04060d_100%)]" />
      <div className="absolute -top-48 right-[-10%] h-[38rem] w-[38rem] rounded-full bg-blue-600/20 blur-[120px]" />
      <div className="absolute top-1/3 left-[-15%] h-[34rem] w-[34rem] rounded-full bg-violet-600/15 blur-[120px]" />
      <div className="absolute bottom-[-20%] right-1/4 h-[30rem] w-[30rem] rounded-full bg-cyan-500/10 blur-[120px]" />
      {/* Fine blueprint grid, faded towards the edges */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(148,163,184,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(148,163,184,0.05)_1px,transparent_1px)] bg-[size:56px_56px] [mask-image:radial-gradient(ellipse_at_center,black_30%,transparent_75%)]" />
      <canvas ref={canvasRef} className="absolute inset-0 opacity-70" />
    </div>
  )
}

const stats = [
  { value: '99.99%', label: 'זמינות מובטחת SLA' },
  { value: '<180ms', label: 'זמן תגובה ממוצע' },
  { value: '24/7', label: 'צוות NOC בעברית' },
  { value: '12K+', label: 'אתרים פעילים' },
]

const rackUnits = [
  { name: 'il-tlv-nvme-01', load: 0.42 },
  { name: 'il-tlv-nvme-02', load: 0.58 },
  { name: 'eu-fra-edge-03', load: 0.31 },
  { name: 'us-nyc-edge-04', load: 0.66 },
]

function RackVisual() {
  const reduceMotion = useReducedMotion()

  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, delay: 0.25, ease: [0.22, 1, 0.36, 1] }}
      className="relative mx-auto w-full max-w-md"
      aria-hidden
    >
      <div className="absolute -inset-6 rounded-[2rem] bg-gradient-to-br from-cyan-500/20 via-blue-600/10 to-violet-600/20 blur-2xl" />
      <motion.div
        animate={reduceMotion ? undefined : { y: [0, -10, 0] }}
        transition={{ duration: 7, repeat: Infinity, ease: 'easeInOut' }}
        className="relative rounded-3xl border border-white/10 bg-slate-900/50 p-5 shadow-2xl shadow-black/40 backdrop-blur-xl"
      >
        <div className="flex items-center justify-between border-b border-white/10 pb-4">
          <div className="flex items-center gap-2 text-sm font-semibold text-slate-200">
            <Activity className="h-4 w-4 text-emerald-400" />
            מצב התשתית
          </div>
          <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-400/10 px-2.5 py-1 text-xs font-medium text-emerald-300 ring-1 ring-emerald-400/20">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" />
            כל המערכות תקינות
          </span>
        </div>

        <div className="mt-4 space-y-2.5" dir="ltr">
          {rackUnits.map((unit, i) => (
            <div
              key={unit.name}
              className="flex items-center gap-3 rounded-xl border border-white/5 bg-white/[0.03] px-3 py-2.5"
            >
              <div className="flex gap-1">
                <span
                  className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400"
                  style={{ animationDelay: `${i * 0.3}s` }}
                />
                <span
                  className="h-1.5 w-1.5 animate-pulse rounded-full bg-cyan-400"
                  style={{ animationDelay: `${i * 0.3 + 0.15}s` }}
                />
              </div>
              <span className="w-32 font-mono text-xs text-slate-400">{unit.name}</span>
              <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/5">
                <motion.div
                  className="h-full rounded-full bg-gradient-to-r from-cyan-400 to-violet-500"
                  initial={{ width: 0 }}
                  animate={
                    reduceMotion
                      ? { width: `${unit.load * 100}%` }
                      : {
                          width: [
                            `${unit.load * 100}%`,
                            `${Math.min(unit.load + 0.18, 0.95) * 100}%`,
                            `${unit.load * 100}%`,
                          ],
                        }
                  }
                  transition={{ duration: 4 + i, repeat: Infinity, ease: 'easeInOut', delay: 0.6 }}
                />
              </div>
            </div>
          ))}
        </div>

        <div className="mt-4 grid grid-cols-3 gap-2.5">
          {[
            { icon: Cpu, label: 'vCPU', value: 'AMD EPYC' },
            { icon: Gauge, label: 'TTFB', value: '42ms' },
            { icon: ShieldCheck, label: 'WAF', value: 'פעיל' },
          ].map((m) => (
            <div key={m.label} className="rounded-xl border border-white/5 bg-white/[0.03] p-3 text-center">
              <m.icon className="mx-auto h-4 w-4 text-cyan-300" />
              <div className="mt-1.5 text-sm font-bold text-white">{m.value}</div>
              <div className="text-[11px] text-slate-500">{m.label}</div>
            </div>
          ))}
        </div>
      </motion.div>
    </motion.div>
  )
}

const fadeUp = {
  hidden: { opacity: 0, y: 18 },
  show: { opacity: 1, y: 0 },
}

export function HeroSection() {
  return (
    <section className="relative pb-20 pt-14 sm:pt-20 lg:pb-28 lg:pt-24">
      <div className="mx-auto grid max-w-7xl items-center gap-16 px-4 sm:px-6 lg:grid-cols-[1.15fr_1fr] lg:px-8">
        <motion.div
          initial="hidden"
          animate="show"
          transition={{ staggerChildren: 0.1 }}
          className="text-center lg:text-start"
        >
          <motion.span
            variants={fadeUp}
            className="inline-flex items-center gap-2 rounded-full border border-cyan-400/20 bg-cyan-400/10 px-4 py-1.5 text-sm font-medium text-cyan-200"
          >
            <Sparkles className="h-4 w-4" aria-hidden />
            דור חדש של תשתיות ענן מנוהלות
          </motion.span>

          <motion.h1
            variants={fadeUp}
            className="mt-7 text-4xl font-extrabold leading-[1.15] tracking-tight text-white sm:text-5xl lg:text-6xl"
          >
            תשתית IT ברמה ארגונית,
            <br />
            <span className="bg-gradient-to-l from-cyan-300 via-blue-400 to-violet-400 bg-clip-text text-transparent">
              בלי הכאב ראש.
            </span>
          </motion.h1>

          <motion.p
            variants={fadeUp}
            className="mx-auto mt-6 max-w-xl text-lg leading-8 text-slate-300 lg:mx-0"
          >
            אחסון מנוהל על דיסקי NVMe ושרתי LiteSpeed, אבטחת סייבר רב-שכבתית וגיבוי אוטומטי – עם
            צוות מהנדסים ישראלי שזמין עבורכם מסביב לשעון.
          </motion.p>

          <motion.div
            variants={fadeUp}
            className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row lg:justify-start"
          >
            <motion.a
              href="#pricing"
              whileHover={{ y: -2 }}
              whileTap={{ scale: 0.98 }}
              className="group inline-flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-l from-cyan-400 to-blue-600 px-7 py-3.5 font-bold text-white shadow-xl shadow-cyan-500/25 transition-shadow hover:shadow-cyan-400/40 sm:w-auto"
            >
              לחבילות האחסון
              <ArrowLeft className="h-4 w-4 transition-transform group-hover:-translate-x-1" aria-hidden />
            </motion.a>
            <motion.a
              href="#experts"
              whileHover={{ y: -2 }}
              whileTap={{ scale: 0.98 }}
              className="inline-flex w-full items-center justify-center gap-2 rounded-xl border border-white/15 bg-white/5 px-7 py-3.5 font-semibold text-white backdrop-blur transition-colors hover:bg-white/10 sm:w-auto"
            >
              <Headset className="h-4 w-4" aria-hidden />
              שיחה עם מומחה
            </motion.a>
          </motion.div>

          <motion.dl
            variants={fadeUp}
            className="mt-12 grid grid-cols-2 gap-x-6 gap-y-6 border-t border-white/10 pt-8 sm:grid-cols-4"
          >
            {stats.map((s) => (
              <div key={s.label}>
                <dt className="sr-only">{s.label}</dt>
                <dd className="text-2xl font-extrabold text-white" dir="ltr">
                  {s.value}
                </dd>
                <dd className="mt-1 text-sm text-slate-400">{s.label}</dd>
              </div>
            ))}
          </motion.dl>
        </motion.div>

        <RackVisual />
      </div>
    </section>
  )
}

export default HeroSection
