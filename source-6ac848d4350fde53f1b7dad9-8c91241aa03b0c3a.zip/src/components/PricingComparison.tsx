import { useState } from 'react'
import { Check } from 'lucide-react'
import { ANNUAL_DISCOUNT, monthlyPriceFor, pricingPlans, type BillingCycle, type PricingPlan } from '@/data/pricing'

export function PricingComparison({ plans = pricingPlans }: { plans?: PricingPlan[] }) {
  const [cycle, setCycle] = useState<BillingCycle>('monthly')

  return (
    <div>
      <div className="mb-10 flex justify-center">
        <div className="inline-flex rounded-full border border-white/10 bg-slate-900/60 p-1 backdrop-blur">
          {(['monthly', 'annual'] as const).map((c) => (
            <button
              key={c}
              type="button"
              aria-pressed={cycle === c}
              onClick={() => setCycle(c)}
              className={`rounded-full px-5 py-2 text-sm font-semibold transition-colors ${
                cycle === c ? 'bg-gradient-to-l from-cyan-400 to-blue-600 text-white' : 'text-slate-300'
              }`}
            >
              {c === 'monthly' ? 'חיוב חודשי' : `חיוב שנתי - ${ANNUAL_DISCOUNT * 100}% הנחה`}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {plans.map((plan) => (
          <div
            key={plan.id}
            className={`relative rounded-3xl border p-7 text-white backdrop-blur-xl transition-transform hover:-translate-y-1 ${
              plan.highlighted
                ? 'order-first border-cyan-400/40 bg-slate-900/70 shadow-2xl shadow-cyan-500/20 lg:order-none'
                : 'border-white/10 bg-slate-900/50'
            }`}
          >
            {plan.badge && (
              <span className="absolute -top-3 right-6 rounded-full bg-gradient-to-l from-cyan-400 to-violet-500 px-3 py-1 text-xs font-bold">
                {plan.badge}
              </span>
            )}
            <h3 className="text-xl font-bold">
              {plan.title} <span className="text-sm font-medium text-slate-400">/ {plan.titleEn}</span>
            </h3>
            <p className="mt-1 text-sm text-slate-400">{plan.tagline}</p>
            <p className="mt-6 text-4xl font-extrabold">
              ₪{monthlyPriceFor(plan, cycle)}
              <span className="text-base font-medium text-slate-400"> / חודש</span>
            </p>

            <div className="mt-6 space-y-3">
              {plan.metrics.map((m) => (
                <div key={m.label}>
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-300">{m.label}</span>
                    <span className="font-semibold">{m.value}</span>
                  </div>
                  <div className="mt-1 h-1.5 rounded-full bg-white/10">
                    <div className="h-full rounded-full bg-gradient-to-l from-cyan-400 to-violet-500" style={{ width: `${m.ratio * 100}%` }} />
                  </div>
                </div>
              ))}
            </div>

            <p className="mt-5 text-sm text-slate-300">
              מיקום שרתים: {plan.locations.map((l) => (l === 'il' ? '🇮🇱 ישראל' : '🌍 גלובלי')).join(' · ')}
            </p>

            <ul className="mt-5 space-y-2 text-sm">
              {plan.features.map((f) => (
                <li key={f} className="flex items-start gap-2">
                  <Check className="mt-0.5 h-4 w-4 shrink-0 text-cyan-300" aria-hidden />
                  <span className={f.includes('חינם') ? 'font-semibold' : ''}>{f}</span>
                </li>
              ))}
            </ul>

            <a
              href={plan.orderUrl[cycle]}
              className={`mt-7 block rounded-xl py-3 text-center font-bold transition-all hover:-translate-y-0.5 ${
                plan.highlighted ? 'bg-gradient-to-l from-cyan-400 to-blue-600 shadow-lg shadow-cyan-500/30' : 'border border-white/15 bg-white/5 hover:bg-white/10'
              }`}
            >
              {plan.ctaLabel}
            </a>
          </div>
        ))}
      </div>
    </div>
  )
}

export default PricingComparison
