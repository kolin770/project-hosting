import { useCallback, useEffect, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import {
  ArrowLeft,
  ArrowLeftRight,
  Asterisk,
  BadgeCheck,
  ChevronDown,
  Cloud,
  DatabaseBackup,
  Globe,
  Headset,
  KeyRound,
  LogIn,
  Menu,
  SearchCheck,
  Server,
  ServerCog,
  ShieldCheck,
  ShoppingCart,
  Waypoints,
  X,
  Zap,
  type LucideIcon,
} from 'lucide-react'

export const BRAND_NAME = 'נובה הוסטינג'

type NavChild = { label: string; description: string; href: string; icon: LucideIcon }
type NavItem = {
  label: string
  href: string
  /** One-line teaser shown in the mega menu's side column. */
  blurb?: string
  children?: NavChild[]
}

const navItems: NavItem[] = [
  { label: 'דף הבית', href: '/' },
  {
    label: 'אחסון אתרים',
    href: '#hosting',
    blurb: 'שרתי LiteSpeed על דיסקי NVMe בישראל ובעולם, מנוהלים על ידי הצוות שלנו.',
    children: [
      {
        label: 'אחסון NVMe מהיר',
        description: 'דיסקים מהירים פי 10 מ-SSD רגיל, לטעינה מיידית',
        href: '#pricing',
        icon: Zap,
      },
      {
        label: 'אחסון WooCommerce מתקדם',
        description: 'משאבים ייעודיים ו-LSCache לחנויות עם תנועה גבוהה',
        href: '#hosting-woocommerce',
        icon: ShoppingCart,
      },
      {
        label: 'אחסון מנוהל לוורדפרס',
        description: 'עדכונים, אבטחה ו-Staging – אנחנו מטפלים בהכול',
        href: '#hosting-wordpress',
        icon: Server,
      },
    ],
  },
  {
    label: 'דומיינים',
    href: '#domains',
    blurb: 'מאות סיומות, כולל ‎.co.il ו-‎.com, עם ניהול DNS מתקדם.',
    children: [
      {
        label: 'רישום דומיין חדש',
        description: 'שריון השם של העסק שלכם בכמה שניות',
        href: '#domains-register',
        icon: Globe,
      },
      {
        label: 'העברת דומיינים',
        description: 'מעבר חלק מכל רשם, בלי זמן השבתה',
        href: '#domains-transfer',
        icon: ArrowLeftRight,
      },
      {
        label: 'בדיקת זמינות Whois',
        description: 'בדיקה מיידית של זמינות ובעלות על דומיין',
        href: '#domains-whois',
        icon: SearchCheck,
      },
    ],
  },
  {
    label: 'שירותי מומחה',
    href: '#experts',
    blurb: 'מהנדסי תשתית ואבטחה שמתכננים, מקימים ומנטרים את הסביבה שלכם.',
    children: [
      {
        label: 'פתרונות ענן מותאמים',
        description: 'ארכיטקטורה גמישה שגדלה יחד עם העסק',
        href: '#experts-cloud',
        icon: Cloud,
      },
      {
        label: 'אבטחת מידע וסייבר',
        description: 'חומות אש, WAF וניטור איומים רציף',
        href: '#experts-security',
        icon: ShieldCheck,
      },
      {
        label: 'גיבוי ארגוני אוטומטי',
        description: 'גיבויים מוצפנים מחוץ לאתר עם שחזור מהיר',
        href: '#experts-backup',
        icon: DatabaseBackup,
      },
    ],
  },
  {
    label: 'תעודות SSL',
    href: '#ssl',
    blurb: 'הצפנה ברמה בנקאית ואמון מיידי של הגולשים ומנועי החיפוש.',
    children: [
      {
        label: 'תעודות DV / OV / EV',
        description: 'אימות דומיין או ארגון, לפי רמת האמון הנדרשת',
        href: '#ssl-validation',
        icon: BadgeCheck,
      },
      {
        label: 'תעודות Wildcard',
        description: 'תעודה אחת לכל תתי-הדומיינים',
        href: '#ssl-wildcard',
        icon: Asterisk,
      },
    ],
  },
  {
    label: 'שרתי VPN',
    href: '#vpn',
    blurb: 'גישה מאובטחת לצוותים מרוחקים ושרתים בשליטה מלאה שלכם.',
    children: [
      {
        label: 'VPN עסקי מאובטח',
        description: 'חיבור מוצפן לעובדים מכל מקום',
        href: '#vpn-business',
        icon: KeyRound,
      },
      {
        label: 'שרתים פרטיים ייעודיים',
        description: 'חומרה ייעודית עם כתובת IP קבועה',
        href: '#vpn-dedicated',
        icon: ServerCog,
      },
    ],
  },
]

// TODO: Point to the WHMCS / FOSSBilling client area, e.g. https://billing.example.co.il/clientarea.php
const CLIENT_PORTAL_URL = '#client-portal'
// TODO: Point to the support ticket form, e.g. https://billing.example.co.il/submitticket.php
const OPEN_TICKET_URL = '#open-ticket'

function Logo() {
  return (
    <a href="/" className="group flex items-center gap-2.5" aria-label={`${BRAND_NAME} – דף הבית`}>
      <span className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-cyan-400 via-blue-500 to-violet-600 text-white shadow-lg shadow-blue-500/30">
        <Waypoints className="h-5 w-5" aria-hidden />
        <span className="absolute inset-0 rounded-xl ring-1 ring-inset ring-white/30" />
      </span>
      <span className="text-xl font-extrabold tracking-tight text-white">{BRAND_NAME}</span>
    </a>
  )
}

function MegaMenu({
  item,
  open,
  onOpen,
  onClose,
}: {
  item: NavItem
  open: boolean
  onOpen: () => void
  onClose: () => void
}) {
  const children = item.children ?? []
  const wide = children.length > 2

  return (
    <div className="relative" onMouseEnter={onOpen} onMouseLeave={onClose}>
      <button
        type="button"
        aria-expanded={open}
        aria-haspopup="true"
        onClick={() => (open ? onClose() : onOpen())}
        className={`flex items-center gap-1 rounded-lg px-3 py-2 text-[15px] font-medium transition-colors ${
          open ? 'bg-white/10 text-white' : 'text-slate-300 hover:bg-white/5 hover:text-white'
        }`}
      >
        {item.label}
        <ChevronDown
          className={`h-4 w-4 transition-transform duration-200 ${open ? 'rotate-180' : ''}`}
          aria-hidden
        />
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -6, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -6, scale: 0.98 }}
            transition={{ duration: 0.18, ease: 'easeOut' }}
            className="absolute right-1/2 top-full translate-x-1/2 pt-3"
          >
            <div
              className={`grid overflow-hidden rounded-2xl border border-white/10 bg-slate-950/85 shadow-2xl shadow-black/50 backdrop-blur-2xl ${
                wide ? 'w-[40rem] grid-cols-[1fr_13rem]' : 'w-[34rem] grid-cols-[1fr_12rem]'
              }`}
            >
              <div className="space-y-1 p-3">
                {children.map((child) => (
                  <a
                    key={child.label}
                    href={child.href}
                    onClick={onClose}
                    className="group flex items-start gap-3 rounded-xl p-3 transition-colors hover:bg-white/[0.06]"
                  >
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-cyan-400/20 bg-cyan-400/10 text-cyan-300 transition-colors group-hover:border-cyan-300/50 group-hover:text-cyan-200">
                      <child.icon className="h-5 w-5" aria-hidden />
                    </span>
                    <span>
                      <span className="block font-semibold text-white">{child.label}</span>
                      <span className="mt-0.5 block text-sm leading-6 text-slate-400">
                        {child.description}
                      </span>
                    </span>
                  </a>
                ))}
              </div>
              <div className="relative flex flex-col justify-between border-r border-white/10 bg-gradient-to-b from-blue-600/15 via-violet-600/10 to-transparent p-5">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.2em] text-cyan-300/80">
                    {item.label}
                  </p>
                  <p className="mt-3 text-sm leading-6 text-slate-300">{item.blurb}</p>
                </div>
                <a
                  href={item.href}
                  onClick={onClose}
                  className="mt-6 inline-flex items-center gap-1.5 text-sm font-semibold text-white hover:text-cyan-200"
                >
                  לכל השירותים
                  <ArrowLeft className="h-4 w-4" aria-hidden />
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

function MobileDrawer({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [expanded, setExpanded] = useState<string | null>(null)

  useEffect(() => {
    if (!open) return
    const prev = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    document.addEventListener('keydown', onKey)
    return () => {
      document.body.style.overflow = prev
      document.removeEventListener('keydown', onKey)
    }
  }, [open, onClose])

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            key="backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm lg:hidden"
          />
          <motion.aside
            key="drawer"
            role="dialog"
            aria-modal="true"
            aria-label="תפריט ניווט"
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', stiffness: 380, damping: 38 }}
            className="fixed inset-y-0 right-0 z-50 flex w-[88%] max-w-sm flex-col border-l border-white/10 bg-slate-950/95 backdrop-blur-2xl lg:hidden"
          >
            <div className="flex items-center justify-between border-b border-white/10 px-5 py-4">
              <Logo />
              <button
                type="button"
                onClick={onClose}
                aria-label="סגירת תפריט"
                className="inline-flex h-10 w-10 items-center justify-center rounded-xl text-slate-300 hover:bg-white/10"
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            <nav aria-label="ניווט ראשי – נייד" className="flex-1 space-y-1 overflow-y-auto px-3 py-4">
              {navItems.map((item) =>
                item.children ? (
                  <div key={item.label}>
                    <button
                      type="button"
                      aria-expanded={expanded === item.label}
                      onClick={() => setExpanded((v) => (v === item.label ? null : item.label))}
                      className="flex w-full items-center justify-between rounded-xl px-3 py-3 text-base font-medium text-slate-100 hover:bg-white/5"
                    >
                      {item.label}
                      <ChevronDown
                        className={`h-5 w-5 text-slate-400 transition-transform ${
                          expanded === item.label ? 'rotate-180' : ''
                        }`}
                        aria-hidden
                      />
                    </button>
                    <AnimatePresence initial={false}>
                      {expanded === item.label && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.22 }}
                          className="overflow-hidden"
                        >
                          <div className="mb-2 mr-3 space-y-1 border-r border-cyan-400/20 pr-2">
                            {item.children.map((child) => (
                              <a
                                key={child.label}
                                href={child.href}
                                onClick={onClose}
                                className="flex items-start gap-3 rounded-lg px-3 py-2.5 hover:bg-white/5"
                              >
                                <child.icon className="mt-0.5 h-4 w-4 shrink-0 text-cyan-300" aria-hidden />
                                <span>
                                  <span className="block text-[15px] text-slate-100">{child.label}</span>
                                  <span className="block text-xs text-slate-400">{child.description}</span>
                                </span>
                              </a>
                            ))}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                ) : (
                  <a
                    key={item.label}
                    href={item.href}
                    onClick={onClose}
                    className="block rounded-xl px-3 py-3 text-base font-medium text-slate-100 hover:bg-white/5"
                  >
                    {item.label}
                  </a>
                ),
              )}
            </nav>

            <div className="space-y-3 border-t border-white/10 p-5">
              <a
                href={CLIENT_PORTAL_URL}
                className="flex items-center justify-center gap-2 rounded-xl bg-gradient-to-l from-cyan-400 to-blue-600 px-4 py-3 font-bold text-white shadow-lg shadow-cyan-500/25"
              >
                <LogIn className="h-4 w-4" aria-hidden />
                אזור לקוחות / התחברות
              </a>
              <a
                href={OPEN_TICKET_URL}
                className="flex items-center justify-center gap-2 rounded-xl border border-white/10 px-4 py-3 text-sm font-semibold text-slate-200 hover:bg-white/5"
              >
                <Headset className="h-4 w-4" aria-hidden />
                פתיחת פניה לתמיכה
              </a>
            </div>
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  )
}

export function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false)
  const [activeMenu, setActiveMenu] = useState<string | null>(null)
  const [scrolled, setScrolled] = useState(false)
  const navRef = useRef<HTMLElement>(null)
  const closeTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined)
  const closeMobile = useCallback(() => setMobileOpen(false), [])

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  // Close the open mega menu on Escape or a click outside the navbar.
  useEffect(() => {
    if (!activeMenu) return
    const onDocClick = (e: MouseEvent) => {
      if (!navRef.current?.contains(e.target as Node)) setActiveMenu(null)
    }
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setActiveMenu(null)
    document.addEventListener('mousedown', onDocClick)
    document.addEventListener('keydown', onKey)
    return () => {
      document.removeEventListener('mousedown', onDocClick)
      document.removeEventListener('keydown', onKey)
    }
  }, [activeMenu])

  // A short close delay lets the pointer travel from the trigger into the panel.
  const openMenu = (label: string) => {
    clearTimeout(closeTimer.current)
    setActiveMenu(label)
  }
  const scheduleClose = () => {
    clearTimeout(closeTimer.current)
    closeTimer.current = setTimeout(() => setActiveMenu(null), 120)
  }

  return (
    <header
      className={`sticky top-0 z-40 transition-all duration-300 ${
        scrolled
          ? 'border-b border-white/10 bg-slate-950/70 shadow-lg shadow-black/20 backdrop-blur-xl'
          : 'border-b border-transparent bg-transparent'
      }`}
    >
      <nav
        ref={navRef}
        aria-label="ניווט ראשי"
        className="mx-auto flex h-18 max-w-7xl items-center justify-between gap-6 px-4 py-3 sm:px-6 lg:px-8"
      >
        <Logo />

        <div className="hidden items-center gap-0.5 lg:flex">
          {navItems.map((item) =>
            item.children ? (
              <MegaMenu
                key={item.label}
                item={item}
                open={activeMenu === item.label}
                onOpen={() => openMenu(item.label)}
                onClose={scheduleClose}
              />
            ) : (
              <a
                key={item.label}
                href={item.href}
                className="rounded-lg px-3 py-2 text-[15px] font-medium text-slate-300 transition-colors hover:bg-white/5 hover:text-white"
              >
                {item.label}
              </a>
            ),
          )}
        </div>

        <div className="hidden items-center gap-2 lg:flex">
          <a
            href={OPEN_TICKET_URL}
            aria-label="פתיחת פניה לתמיכה"
            className="inline-flex h-10 w-10 items-center justify-center rounded-xl text-slate-300 transition-colors hover:bg-white/10 hover:text-white"
          >
            <Headset className="h-5 w-5" aria-hidden />
          </a>
          <a
            href={CLIENT_PORTAL_URL}
            className="group relative inline-flex items-center gap-2 overflow-hidden rounded-xl bg-gradient-to-l from-cyan-400 to-blue-600 px-5 py-2.5 text-sm font-bold text-white shadow-lg shadow-cyan-500/30 transition-all hover:shadow-cyan-400/50 focus:outline-none focus-visible:ring-4 focus-visible:ring-cyan-300/40"
          >
            <span
              aria-hidden
              className="absolute inset-0 -translate-x-full bg-gradient-to-l from-transparent via-white/30 to-transparent transition-transform duration-700 group-hover:translate-x-full"
            />
            <LogIn className="relative h-4 w-4" aria-hidden />
            <span className="relative">אזור לקוחות / התחברות</span>
          </a>
        </div>

        <button
          type="button"
          className="inline-flex h-11 w-11 items-center justify-center rounded-xl text-slate-200 hover:bg-white/10 lg:hidden"
          aria-label="פתיחת תפריט"
          aria-expanded={mobileOpen}
          onClick={() => setMobileOpen(true)}
        >
          <Menu className="h-6 w-6" />
        </button>
      </nav>

      <MobileDrawer open={mobileOpen} onClose={closeMobile} />
    </header>
  )
}

export default Navbar
